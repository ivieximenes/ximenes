package br.com.qualicorp.redenarede.service.auditoria.to;

public class RelationTO
{
	private String title;
	
	 private String childColumn;
	 private String parentColumn;
	 
	 private TableTO table;
	 
	public TableTO getTable() {
		return table;
	}
	public void setTable(TableTO table) {
		this.table = table;
	}
	public String getChildColumn()
	{
		return childColumn;
	}
	public void setChildColumn(String childColumn)
	{
		this.childColumn = childColumn;
	}
	public String getParentColumn()
	{
		return parentColumn;
	}
	public void setParentColumn(String parentColumn)
	{
		this.parentColumn = parentColumn;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
}
@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.autenticacao.ws.tempoassist.com.br", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.qualicorp.redenarede.webservice.stub.beneficiario;

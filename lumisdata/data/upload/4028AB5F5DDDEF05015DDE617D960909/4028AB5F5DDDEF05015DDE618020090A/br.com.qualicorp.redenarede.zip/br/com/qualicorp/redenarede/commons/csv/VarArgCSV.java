package br.com.qualicorp.redenarede.commons.csv;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)

public @interface VarArgCSV
{
	String label();
}
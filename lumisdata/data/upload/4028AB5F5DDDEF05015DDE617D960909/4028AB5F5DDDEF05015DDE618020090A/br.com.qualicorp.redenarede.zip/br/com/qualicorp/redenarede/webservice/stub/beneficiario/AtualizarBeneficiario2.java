package br.com.qualicorp.redenarede.webservice.stub.beneficiario;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AtualizarBeneficiario", namespace = "http://ws.beneficiario.tempoassist.com.br/schema", propOrder = {
    "codigoEstipulante",
    "codigoBeneficiario",
    "email",
    "ddd",
    "numTel"
})
public class AtualizarBeneficiario2 {

    @XmlElement(required = true)
    protected String codigoEstipulante;
    @XmlElement(required = true)
    protected String codigoBeneficiario;
    @XmlElement(required = true)
    protected String email;
    @XmlElement(required = true)
    protected String ddd;
    @XmlElement(required = true)
    protected String numTel;

    public String getCodigoEstipulante() {
        return codigoEstipulante;
    }

    public void setCodigoEstipulante(String value) {
        this.codigoEstipulante = value;
    }

    public String getCodigoBeneficiario() {
        return codigoBeneficiario;
    }

    public void setCodigoBeneficiario(String value) {
        this.codigoBeneficiario = value;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String value) {
        this.email = value;
    }

    public String getDdd() {
        return ddd;
    }

    public void setDdd(String value) {
        this.ddd = value;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String value) {
        this.numTel = value;
    }
}
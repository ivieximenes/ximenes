
package br.com.qualicorp.redenarede.webservice.stub.beneficiario;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="operadora" type="{http://ws.common.tempoassist.com.br/schema}Operadora" minOccurs="0"/>
 *         &lt;element name="autenticacaoBeneficiario" type="{http://ws.beneficiario.tempoassist.com.br/schema}AutenticacaoBeneficiario" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "operadora",
    "autenticacaoBeneficiario"
})
@XmlRootElement(name = "recuperarSenha")
public class RecuperarSenha {

    protected Operadora operadora;
    protected AutenticacaoBeneficiario autenticacaoBeneficiario;

    /**
     * Gets the value of the operadora property.
     * 
     * @return
     *     possible object is
     *     {@link Operadora }
     *     
     */
    public Operadora getOperadora() {
        return operadora;
    }

    /**
     * Sets the value of the operadora property.
     * 
     * @param value
     *     allowed object is
     *     {@link Operadora }
     *     
     */
    public void setOperadora(Operadora value) {
        this.operadora = value;
    }

    /**
     * Gets the value of the autenticacaoBeneficiario property.
     * 
     * @return
     *     possible object is
     *     {@link AutenticacaoBeneficiario }
     *     
     */
    public AutenticacaoBeneficiario getAutenticacaoBeneficiario() {
        return autenticacaoBeneficiario;
    }

    /**
     * Sets the value of the autenticacaoBeneficiario property.
     * 
     * @param value
     *     allowed object is
     *     {@link AutenticacaoBeneficiario }
     *     
     */
    public void setAutenticacaoBeneficiario(AutenticacaoBeneficiario value) {
        this.autenticacaoBeneficiario = value;
    }

}


package br.com.qualicorp.redenarede.webservice.stub.pretador;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="usuarioPrestador" type="{http://schemas.datacontract.org/2004/07/Qualicorp.GSP.Contratos.GestaoPrestador}UsuarioPrestador" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "usuarioPrestador"
})
@XmlRootElement(name = "ValidarUsuarioPrestador")
public class ValidarUsuarioPrestador {

    @XmlElement(nillable = true)
    protected UsuarioPrestador usuarioPrestador;

    /**
     * Gets the value of the usuarioPrestador property.
     * 
     * @return
     *     possible object is
     *     {@link UsuarioPrestador }
     *     
     */
    public UsuarioPrestador getUsuarioPrestador() {
        return usuarioPrestador;
    }

    /**
     * Sets the value of the usuarioPrestador property.
     * 
     * @param value
     *     allowed object is
     *     {@link UsuarioPrestador }
     *     
     */
    public void setUsuarioPrestador(UsuarioPrestador value) {
        this.usuarioPrestador = value;
    }

}

package br.com.qualicorp.redenarede.service.administracaodelayout.to;

public class LayoutTO
{
	private String idlayout;
	private String nomeLayout;
	private String corDeFundo;
	private String corDaLetra;
	private String fonteDaLetra;
	
	public String getNomeLayout()
	{
		return nomeLayout;
	}
	public void setNomeLayout(String nomeLayout)
	{
		this.nomeLayout = nomeLayout;
	}
	public String getCorDeFundo()
	{
		return corDeFundo;
	}
	public void setCorDeFundo(String corDeFundo)
	{
		this.corDeFundo = corDeFundo;
	}
	public String getCorDaLetra()
	{
		return corDaLetra;
	}
	public void setCorDaLetra(String corDaLetra)
	{
		this.corDaLetra = corDaLetra;
	}
	public String getFonteDaLetra()
	{
		return fonteDaLetra;
	}
	public void setFonteDaLetra(String fonteDaLetra)
	{
		this.fonteDaLetra = fonteDaLetra;
	}
	public String getIdlayout()
	{
		return idlayout;
	}
	public void setIdlayout(String idlayout)
	{
		this.idlayout = idlayout;
	}
}
package br.com.qualicorp.redenarede.service.auditoria.enums;

public enum AuditiaOperationEnum
{
	INSERT, 
	UPDATE, 
	DELETE;
}
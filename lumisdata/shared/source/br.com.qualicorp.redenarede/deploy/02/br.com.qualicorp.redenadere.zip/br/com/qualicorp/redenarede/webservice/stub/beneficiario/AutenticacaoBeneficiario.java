
package br.com.qualicorp.redenarede.webservice.stub.beneficiario;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AutenticacaoBeneficiario complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AutenticacaoBeneficiario">
 *   &lt;complexContent>
 *     &lt;extension base="{http://ws.beneficiario.tempoassist.com.br/schema}Beneficiario">
 *       &lt;sequence>
 *         &lt;element name="usuario" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="senha" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="senhaAnterior" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="confirmacaoSenha" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="confirmacaoEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AutenticacaoBeneficiario", namespace = "http://ws.beneficiario.tempoassist.com.br/schema", propOrder = {
    "usuario",
    "senha",
    "senhaAnterior",
    "confirmacaoSenha",
    "confirmacaoEmail"
})
public class AutenticacaoBeneficiario
    extends Beneficiario
{

    @XmlElement(nillable = true)
    protected String usuario;
    @XmlElement(nillable = true)
    protected String senha;
    @XmlElement(nillable = true)
    protected String senhaAnterior;
    @XmlElement(nillable = true)
    protected String confirmacaoSenha;
    @XmlElement(nillable = true)
    protected String confirmacaoEmail;

    /**
     * Gets the value of the usuario property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * Sets the value of the usuario property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsuario(String value) {
        this.usuario = value;
    }

    /**
     * Gets the value of the senha property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenha() {
        return senha;
    }

    /**
     * Sets the value of the senha property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenha(String value) {
        this.senha = value;
    }

    /**
     * Gets the value of the senhaAnterior property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenhaAnterior() {
        return senhaAnterior;
    }

    /**
     * Sets the value of the senhaAnterior property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenhaAnterior(String value) {
        this.senhaAnterior = value;
    }

    /**
     * Gets the value of the confirmacaoSenha property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfirmacaoSenha() {
        return confirmacaoSenha;
    }

    /**
     * Sets the value of the confirmacaoSenha property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfirmacaoSenha(String value) {
        this.confirmacaoSenha = value;
    }

    /**
     * Gets the value of the confirmacaoEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfirmacaoEmail() {
        return confirmacaoEmail;
    }

    /**
     * Sets the value of the confirmacaoEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfirmacaoEmail(String value) {
        this.confirmacaoEmail = value;
    }

}

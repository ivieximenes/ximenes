package br.com.qualicorp.redenarede.webservice.manager;

import java.io.File;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import br.com.qualicorp.redenarede.webservice.stub.beneficiario.AutenticacaoBeneficiario;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.AutenticacaoBeneficiarioService;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.AutenticacaoBeneficiarioService_Service;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.Autenticar;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.AutenticarResponse;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.CriarSenha;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.CriarSenhaResponse;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.Operadora;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.RecuperarSenha;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.RecuperarSenhaResponse;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.TrocarSenha;
import br.com.qualicorp.redenarede.webservice.stub.beneficiario.TrocarSenhaResponse;
import lumis.portal.PortalContext;
import lumis.portal.PortalException;
import lumis.portal.serviceinterface.IServiceInterfaceRequest;
import lumis.util.XmlUtil;

public class BeneficiarioWebServiceManager {
	private final Operadora operadora;
	private final AutenticacaoBeneficiarioService_Service service;
	static {
	    javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
	    new javax.net.ssl.HostnameVerifier(){
	        public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
	            return true;
	        }
	    });
	}
	public BeneficiarioWebServiceManager() throws Exception
	{
		try {
			Document dom = XmlUtil.getDocument(new File(PortalContext.getConfigPath("/webServiceConfig.xml")));
			Node config = XmlUtil.selectSingleNode("/webServiceConfig/beneficiario", dom);
			service = new AutenticacaoBeneficiarioService_Service();
			operadora = new Operadora();
			operadora.setCodigo(XmlUtil.readAttributeOrNodeString(config, "codigoOperadora"));
			ssl();
		} catch (PortalException e) {
			throw new PortalException(e.getMessage());
		}
	}
	public CriarSenhaResponse cadastrarBeneficiario(IServiceInterfaceRequest request) throws Exception
	{
		try {
			AutenticacaoBeneficiario beneficiario = new AutenticacaoBeneficiario();
			beneficiario.setNome(request.getParameter("nome"));
			beneficiario.setNomeMae(request.getParameter("nome-mae"));
			beneficiario.setCpf(request.getParameter("cpf"));
			beneficiario.setNumeroCNS(request.getParameter("numero-carteira"));
			beneficiario.setEmail(request.getParameter("email"));
			beneficiario.setConfirmacaoEmail(request.getParameter("email"));
			beneficiario.setRg(request.getParameter("rg"));
			beneficiario.setOrgaoEmissor(request.getParameter("orgao-emissor"));
			beneficiario.setSenha(request.getParameter("senha"));
			beneficiario.setConfirmacaoSenha(request.getParameter("confirmpassword"));
			SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
			Date dataNascimento    = dateFormatter.parse(request.getParameter("data_nascimento"));
			GregorianCalendar gregorianCalendar = new GregorianCalendar();
			XMLGregorianCalendar xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
			gregorianCalendar.setTime(dataNascimento);
			beneficiario.setDataNascimento(xmlGregorianCalendar);
			
			CriarSenha criarSenha = new CriarSenha();
			criarSenha.setOperadora(this.operadora);
			criarSenha.setAutenticacaoBeneficiario(beneficiario );
			
		
			CriarSenhaResponse response = service.getAutenticacaoBeneficiarioServiceHttpSoapEndpoint().criarSenha(criarSenha);
			return response;
		} catch (AutenticacaoBeneficiarioService e) {
			throw new PortalException(e.getMessage());
		}
	}
	
	public AutenticarResponse login(String login, String password) throws Exception
	{
		try {
			Autenticar autenticar = new Autenticar();
			AutenticacaoBeneficiario beneficiario = new AutenticacaoBeneficiario();
			beneficiario.setUsuario(login);
			beneficiario.setSenha(password);
			autenticar.setAutenticacaoBeneficiario(beneficiario);
			AutenticarResponse response = service.getAutenticacaoBeneficiarioServiceHttpSoapEndpoint().autenticar(autenticar );
			return response;
		} catch (AutenticacaoBeneficiarioService e) {
			throw new PortalException(e.getMessage());
		}
	}
	
	/**
	 * Ignora certificados SSL invalidos
	 */
	private void ssl() {
		TrustManager[] trustAllCerts = new TrustManager[]{
		    new X509TrustManager() {
		        public void checkClientTrusted(
		            java.security.cert.X509Certificate[] certs, String authType) {
		        }
		        public void checkServerTrusted(
		            java.security.cert.X509Certificate[] certs, String authType) {
		        }
		        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		            return null;
		        }
		    }
		};

		// Install the all-trusting trust manager
		try {
		    SSLContext sc = SSLContext.getInstance("SSL");
		    sc.init(null, trustAllCerts, new java.security.SecureRandom());
		    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
		}
	}
	public TrocarSenhaResponse alterarSenha(String login, String password, String newPassword, String confirmNewPassword) throws Exception {
		TrocarSenhaResponse response = new TrocarSenhaResponse();
		try {
			TrocarSenha trocarSenha = new TrocarSenha();
			trocarSenha.setOperadora(operadora);
			AutenticacaoBeneficiario autenticacaoBeneficiario = new AutenticacaoBeneficiario();
			autenticacaoBeneficiario.setUsuario(login);
			autenticacaoBeneficiario.setSenhaAnterior(password);
			autenticacaoBeneficiario.setSenha(newPassword);
			autenticacaoBeneficiario.setConfirmacaoSenha(confirmNewPassword);
			trocarSenha.setAutenticacaoBeneficiario(autenticacaoBeneficiario );
			response = service.getAutenticacaoBeneficiarioServiceHttpSoapEndpoint().trocarSenha(trocarSenha );
		} catch (AutenticacaoBeneficiarioService e) {
			throw new PortalException(e.getMessage());
		}
		return response;
		
	}
	public RecuperarSenhaResponse recuperarSenha(String cpf, String email) throws PortalException {
		
		RecuperarSenhaResponse response = new RecuperarSenhaResponse();
		try {
			RecuperarSenha recuperarSenha = new RecuperarSenha();
			recuperarSenha.setOperadora(operadora);
			AutenticacaoBeneficiario autenticacaoBeneficiario = new AutenticacaoBeneficiario();
			autenticacaoBeneficiario.setCpf(cpf);
			autenticacaoBeneficiario.setEmail(email);
			recuperarSenha.setAutenticacaoBeneficiario(autenticacaoBeneficiario );
			response = service.getAutenticacaoBeneficiarioServiceHttpSoapEndpoint().recuperarSenha(recuperarSenha);
		} catch (AutenticacaoBeneficiarioService e) {
			throw new PortalException(e.getMessage());
		}
		return response;
	}
	
}

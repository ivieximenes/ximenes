package br.com.qualicorp.redenarede.service.login.processaction;

import br.com.qualicorp.redenarede.service.useraccount.manager.UserAccountManager;
import lumis.doui.processaction.ProcessActionHandler;
import lumis.doui.table.TableSource;
import lumis.portal.PortalException;
import lumis.portal.authentication.SessionConfig;
import lumis.portal.manager.ManagerFactory;
import lumis.portal.user.UserConfig;
import lumis.util.XmlUtil;

public class EsqueciSenhaProcessActionHandler  extends ProcessActionHandler<TableSource>
	{
		public static final String ACTION_BENEFICIARIO = "esqueciSenhaBeneficiario";
		public static final String ACTION_PRESTADOR = "esqueciSenhaPrestador";

		@Override
		public void processAction() throws PortalException
		{
			String actionType = XmlUtil.readAttributeString("actionType", processActionNode);

			if (actionType.equals(ACTION_BENEFICIARIO))
				processBeneficiarioAction();
			else if (actionType.equals(ACTION_PRESTADOR))
				processPrestadorAction();
						
			addDefaultResponse();
		}
		
		private void processBeneficiarioAction() throws PortalException
		{
				String email = getParameter("email", String.class); 
				String cpf = getParameter("cpf", String.class);
				UserAccountManager userAccountManager = new UserAccountManager();
				try
				{
					String login = userAccountManager.getLoginBeneficiarioByCpf(cpf, transaction);
					if(login==null)
						throw new lumis.portal.PortalException("CPF '"+cpf+"' não encontrado.");
					else
					{
						String userId = ManagerFactory.getUserManager().getUserIdByLogin(SessionConfig.getCurrentSessionConfig(), login, transaction);
						UserConfig userConfig = ManagerFactory.getUserManager().get(sessionConfig, userId, transaction);
						if(!userConfig.getEmail().equalsIgnoreCase(email))
							throw new lumis.portal.PortalException("E-mail '"+email+"' não encontrado.");
					}
					
					/*BeneficiarioWebServiceManager beneficiarioWS = new BeneficiarioWebServiceManager();
					RecuperarSenhaResponse recuperarSenha = beneficiarioWS.recuperarSenha(cpf, email);
					if(!recuperarSenha.isResultado())
						throw new PortalException(recuperarSenha.getMensagem());*/
				}
				catch(Exception e)
				{
					throw new PortalException(e.getMessage());
				}
				
		}
		
		private void processPrestadorAction() throws PortalException
		{
			String email = getParameter("email", String.class); 
			String cpfCnpj = getParameter("cpf_cnpj", String.class);
			UserAccountManager userAccountManager = new UserAccountManager();
			try
			{
				String login = userAccountManager.getLognPrestadorByCpfCnpj(cpfCnpj, transaction);
				if(login==null)
					throw new lumis.portal.PortalException("CPF/CNPJ '"+cpfCnpj+"' não encontrado.");
				else
				{
					String userId = ManagerFactory.getUserManager().getUserIdByLogin(SessionConfig.getCurrentSessionConfig(), login, transaction);
					UserConfig userConfig = ManagerFactory.getUserManager().get(sessionConfig, userId, transaction);
					if(!userConfig.getEmail().equalsIgnoreCase(email))
						throw new lumis.portal.PortalException("E-mail '"+email+"' não encontrado.");
				}
				
			/*	PrestadorWebServiceManager prestadorWS = new PrestadorWebServiceManager();
				RecuperarSenhaUsuarioPrestadorResponse recuperarSenha = prestadorWS.recuperarSenha(cpfCnpj, email);*/
				
			}
			catch(Exception e)
			{
				throw new PortalException(e.getMessage());
			}
		}
		
}

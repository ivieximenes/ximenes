
package br.com.qualicorp.redenarede.webservice.stub.beneficiario;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Hierarquia complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Hierarquia">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigoSistema" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="estipulante" type="{http://ws.common.tempoassist.com.br/schema}Operadora" minOccurs="0"/>
 *         &lt;element name="operadora" type="{http://ws.common.tempoassist.com.br/schema}Operadora" minOccurs="0"/>
 *         &lt;element name="subestipulante" type="{http://ws.common.tempoassist.com.br/schema}Operadora" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Hierarquia", propOrder = {
    "codigoSistema",
    "estipulante",
    "operadora",
    "subestipulante"
})
public class Hierarquia {

    @XmlElement(nillable = true)
    protected String codigoSistema;
    @XmlElement(nillable = true)
    protected Operadora estipulante;
    @XmlElement(nillable = true)
    protected Operadora operadora;
    @XmlElement(nillable = true)
    protected Operadora subestipulante;

    /**
     * Gets the value of the codigoSistema property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoSistema() {
        return codigoSistema;
    }

    /**
     * Sets the value of the codigoSistema property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoSistema(String value) {
        this.codigoSistema = value;
    }

    /**
     * Gets the value of the estipulante property.
     * 
     * @return
     *     possible object is
     *     {@link Operadora }
     *     
     */
    public Operadora getEstipulante() {
        return estipulante;
    }

    /**
     * Sets the value of the estipulante property.
     * 
     * @param value
     *     allowed object is
     *     {@link Operadora }
     *     
     */
    public void setEstipulante(Operadora value) {
        this.estipulante = value;
    }

    /**
     * Gets the value of the operadora property.
     * 
     * @return
     *     possible object is
     *     {@link Operadora }
     *     
     */
    public Operadora getOperadora() {
        return operadora;
    }

    /**
     * Sets the value of the operadora property.
     * 
     * @param value
     *     allowed object is
     *     {@link Operadora }
     *     
     */
    public void setOperadora(Operadora value) {
        this.operadora = value;
    }

    /**
     * Gets the value of the subestipulante property.
     * 
     * @return
     *     possible object is
     *     {@link Operadora }
     *     
     */
    public Operadora getSubestipulante() {
        return subestipulante;
    }

    /**
     * Sets the value of the subestipulante property.
     * 
     * @param value
     *     allowed object is
     *     {@link Operadora }
     *     
     */
    public void setSubestipulante(Operadora value) {
        this.subestipulante = value;
    }

}

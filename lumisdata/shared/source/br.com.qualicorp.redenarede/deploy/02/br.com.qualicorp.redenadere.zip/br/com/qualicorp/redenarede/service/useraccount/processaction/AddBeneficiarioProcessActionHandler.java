package br.com.qualicorp.redenarede.service.useraccount.processaction;

import br.com.qualicorp.redenarede.service.useraccount.manager.UserAccountManager;
import lumis.doui.table.TableAddDataProcessActionHandler;
import lumis.portal.PortalException;
import lumis.portal.PortalObjectNotFoundException;
import lumis.portal.authentication.SessionConfig;
import lumis.portal.manager.ManagerFactory;
import lumis.portal.principal.PrincipalConfig;
import lumis.portal.user.UserConfig;

public class AddBeneficiarioProcessActionHandler extends TableAddDataProcessActionHandler
{
	
	final String  QC_BENEFICIARIO = "qc.beneficiario";
	@Override
	public void processAction() throws PortalException
	{	
		UserAccountManager userAccountManager = new UserAccountManager();
		try
		{
			String userIdByLogin = ManagerFactory.getUserManager().getUserIdByLogin(SessionConfig.getCurrentSessionConfig(), (String) getParameter("numero_carteira"), transaction);
			if(userIdByLogin !=null)
				throw new lumis.portal.PortalException("Usuário '"+(String) getParameter("numero_carteira")+"' já previamente cadastrado.");
		}
		catch(PortalObjectNotFoundException p)
		{
			boolean userExists = userAccountManager.beneficiarioExistente((String)getParameter("cpf"), transaction);
			if(userExists)
				throw new lumis.portal.PortalException("CPF'"+(String)getParameter("cpf")+"' já previamente cadastrado.");
			
			/*try {
				BeneficiarioWebServiceManager  beneficiarioWS = new BeneficiarioWebServiceManager();
				CriarSenhaResponse cadastrarBeneficiario = beneficiarioWS.cadastrarBeneficiario(douiContext.getRequest());
				if(!cadastrarBeneficiario.isResultado())
					throw new PortalException(cadastrarBeneficiario.getMensagem());
			} catch (Exception e) {
				throw new PortalException(e.getMessage());
			}*/
			
		}
		
		String userId = addUser();
		setParameter("user_id", userId);
		super.processAction();
		
	}


	

	private String addUser() throws PortalException{
		UserConfig userConfig = new UserConfig();
		userConfig.setLogin((String) getParameter("numero_carteira"));
		userConfig.setFirstName((String) getParameter("nome"));
		userConfig.setEmail((String) getParameter("email"));
		userConfig.setPassword((String) getParameter("password"));
		
		SessionConfig systemUser = ManagerFactory.getAuthenticationManager().impersonate(UserConfig.USER_SYSTEM_ID);
		String userId = null;
		try
		{
			userId = ManagerFactory.getUserManager().add(systemUser, userConfig, transaction);
			PrincipalConfig grupo = ManagerFactory.getPrincipalManager().getByShortId(systemUser, QC_BENEFICIARIO, transaction);
			ManagerFactory.getGroupManager().addMember(systemUser, grupo.getId(), userConfig.getId(), transaction);
        }
		catch(Exception e)
        {
            throw new PortalException(e.getMessage());
        }
		finally
		{
			ManagerFactory.getAuthenticationManager().endImpersonation(systemUser);
		}
		return userId;
	}
	
}
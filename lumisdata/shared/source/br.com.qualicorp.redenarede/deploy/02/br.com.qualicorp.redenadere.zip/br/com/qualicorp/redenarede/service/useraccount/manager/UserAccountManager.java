package br.com.qualicorp.redenarede.service.useraccount.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.json.simple.JSONObject;

import lumis.portal.PortalException;
import lumis.portal.UnexpectedException;
import lumis.portal.dao.jdbc.ITransactionJdbc;
import lumis.portal.transaction.PortalTransactionFactory;
import lumis.util.ITransaction;

public class UserAccountManager {
	public boolean beneficiarioExistente(String cpf_cnpj, ITransaction transaction) throws UnexpectedException 
	{
		try
		{
			boolean existeUsuario = false;
			
			ITransactionJdbc daoTransactionJdbc = (ITransactionJdbc) transaction;
			Connection connection = daoTransactionJdbc.getConnection();

			PreparedStatement statement = connection.prepareStatement(" select * from QC_BENEFICIARIO where cpf = ? ");
			try
			{
				statement.setString(1, cpf_cnpj);
				ResultSet resultSet = statement.executeQuery();
				try
				{
					if (resultSet.next())
					{
						existeUsuario = true;
						
					}
				}
				finally
				{
					resultSet.close();
				}
			}
			finally
			{
				statement.close();
			}
			
			
			return existeUsuario;
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
	}
	
	public String getLoginBeneficiarioByCpf(String cpf, ITransaction transaction) throws UnexpectedException 
	{
		try
		{
			ITransactionJdbc daoTransactionJdbc = (ITransactionJdbc) transaction;
			Connection connection = daoTransactionJdbc.getConnection();
			PreparedStatement statement = connection.prepareStatement(" select numero_carteira from QC_BENEFICIARIO where cpf = ? ");
			try
			{
				statement.setString(1, cpf);
				ResultSet resultSet = statement.executeQuery();
				try
				{
					if (resultSet.next())
					{
						return resultSet.getString("numero_carteira");
						
					}
				}
				finally
				{
					resultSet.close();
				}
			}
			finally
			{
				statement.close();
			}
			
			
			return null;
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
	}
	
	
	public boolean prestadorExistente(String cpf_cnpj, ITransaction transaction) throws UnexpectedException 
	{
		try
		{
			boolean existeUsuario = false;
			
			ITransactionJdbc daoTransactionJdbc = (ITransactionJdbc) transaction;
			Connection connection = daoTransactionJdbc.getConnection();

			PreparedStatement statement = connection.prepareStatement(" select * from QC_PRESTADOR where cpf_cnpj = ? ");
			try
			{
				statement.setString(1, cpf_cnpj);
				ResultSet resultSet = statement.executeQuery();
				try
				{
					if (resultSet.next())
					{
						existeUsuario = true;
						
					}
				}
				finally
				{
					resultSet.close();
				}
			}
			finally
			{
				statement.close();
			}
			
			
			return existeUsuario;
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
	}
	
	public String getLognPrestadorByCpfCnpj(String cpf_cnpj, ITransaction transaction) throws UnexpectedException 
	{
		try
		{
			
			ITransactionJdbc daoTransactionJdbc = (ITransactionJdbc) transaction;
			Connection connection = daoTransactionJdbc.getConnection();

			PreparedStatement statement = connection.prepareStatement(" select usuario from QC_PRESTADOR where cpf_cnpj = ? ");
			try
			{
				statement.setString(1, cpf_cnpj);
				ResultSet resultSet = statement.executeQuery();
				try
				{
					if (resultSet.next())
					{
						return resultSet.getString("usuario");
						
					}
				}
				finally
				{
					resultSet.close();
				}
			}
			finally
			{
				statement.close();
			}
			
			
			return null;
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
	}

	@SuppressWarnings({ "unchecked" })
	public JSONObject getDadosbeneficiarioJSON(String userId) throws PortalException {
		ITransactionJdbc transaction = (ITransactionJdbc) PortalTransactionFactory.createTransaction();
		JSONObject beneficiario = new JSONObject();
		try
		{
			transaction.begin();
			Connection connection = transaction.getConnection();

			PreparedStatement statement = connection.prepareStatement(" select nome_mae, telefone, data_nascimento, rg, orgao_emissor, numero_carteira, cpf  from QC_BENEFICIARIO where user_id = ? ");
			try
			{
				statement.setString(1, userId);
				ResultSet resultSet = statement.executeQuery();
				try
				{
					if (resultSet.next())
					{
						 beneficiario.put("nome_mae", resultSet.getString("nome_mae"));
						 beneficiario.put("telefone", resultSet.getString("telefone"));
						 beneficiario.put("data_nascimento", resultSet.getDate("data_nascimento"));
						 beneficiario.put("rg", resultSet.getString("rg"));
						 beneficiario.put("orgao_emissor", resultSet.getString("orgao_emissor"));
						 beneficiario.put("numero_carteira", resultSet.getString("numero_carteira"));
						 beneficiario.put("cpf", resultSet.getString("cpf"));
					}
				}
				finally
				{
					resultSet.close();
				}
			}
			finally
			{
				statement.close();
			}
			
		}
		catch (Exception e)
		{
			throw new PortalException(e.getMessage());
		}finally {
			transaction.commit();
		}
		return beneficiario;
		
	}
	
}

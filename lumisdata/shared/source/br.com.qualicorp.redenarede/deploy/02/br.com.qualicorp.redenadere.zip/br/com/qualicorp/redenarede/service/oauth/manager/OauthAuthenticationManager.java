package br.com.qualicorp.redenarede.service.oauth.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import lumis.portal.UnexpectedException;
import lumis.portal.dao.jdbc.ITransactionJdbc;
import lumis.portal.transaction.PortalTransactionFactory;

public class OauthAuthenticationManager {
	
	public String getRefreshToken(String userId, String system) throws UnexpectedException 
	{
		try
		{
			ITransactionJdbc transaction = (ITransactionJdbc) PortalTransactionFactory.createTransaction();
			transaction.begin();
			Connection connection = transaction.getConnection();

			PreparedStatement statement = connection.prepareStatement(" select refresh_token from QC_OAUTH where user_id = ? and system=? ");
			try
			{
				statement.setString(1, userId);
				statement.setString(2, system);
				ResultSet resultSet = statement.executeQuery();
				try
				{
					if (resultSet.next())
					{
						return resultSet.getString("refresh_token");
					}
				}
				finally
				{
					resultSet.close();
				}
			}
			finally
			{
				statement.close();
				transaction.commit();
			}
			
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
		return null;
	}
	
	
	public boolean addRefreshToken(String id, String userId, String system) throws UnexpectedException 
	{
		try
		{
		
			ITransactionJdbc transaction = (ITransactionJdbc) PortalTransactionFactory.createTransaction();
			transaction.begin();
			Connection connection = transaction.getConnection();
			PreparedStatement statement = connection.prepareStatement("insert into QC_OAUTH values(?, ?, ?)");
			try
			{
				statement.setString(1, id);
				statement.setString(2, userId);
				statement.setString(3, system);
				return statement.execute();
			}
			finally
			{
				statement.close();
				transaction.commit();
			}
			
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
	}

	
	public boolean updateRefreshToken(String newToken, String oldToken) throws UnexpectedException 
	{
		try
		{
		
			ITransactionJdbc transaction = (ITransactionJdbc) PortalTransactionFactory.createTransaction();
			transaction.begin();
			Connection connection = transaction.getConnection();
			PreparedStatement statement = connection.prepareStatement(" update QC_OAUTH set refresh_token = ? where refresh_token=?");
			try
			{
				statement.setString(1, newToken);
				statement.setString(2, oldToken);
				return statement.execute();
			}
			finally
			{
				statement.close();
				transaction.commit();
			}
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
	}


	public void deleteRefreshToken(String token) throws UnexpectedException {
		try
		{
		
			ITransactionJdbc transaction = (ITransactionJdbc) PortalTransactionFactory.createTransaction();
			transaction.begin();
			Connection connection = transaction.getConnection();
			PreparedStatement statement = connection.prepareStatement(" delete from  QC_OAUTH where refresh_token=?");
			try
			{
				statement.setString(1, token);
				statement.execute();
			}
			finally
			{
				statement.close();
				transaction.commit();
			}
		}
		catch (Exception e)
		{
			throw new UnexpectedException(e);
		}
		
	}
	
}

package br.com.qualicorp.redenarede.service.businesscontact.processaction;

import lumis.doui.processaction.GenericProcessActionHandler;
import lumis.doui.source.field.ISourceField;
import lumis.portal.PortalException;
import lumis.portal.authentication.SessionConfig;
import lumis.portal.manager.ManagerFactory;
import lumis.portal.sendmail.IMailConfig;
import lumis.portal.sendmail.ISendMailManager;
import lumis.portal.sendmail.ISingleMail;
import lumis.portal.serviceinstance.ServiceInstanceConfig;

public class SendEmailProcessActionHandler extends GenericProcessActionHandler
{

	@Override
	public void processAction() throws PortalException
	{
		// get destination email
		ServiceInstanceConfig serviceInstanceConfig = ManagerFactory.getServiceInstanceManager().get(this.douiContext.getActionRequest().getServiceInstanceConfig().getId(), transaction);
		String emailto = ManagerFactory.getPropertyBagManager().get(serviceInstanceConfig.getPropertyBagId()).getValue("email-to", null);
		if(emailto == null)
			return;
		String emailfrom = ManagerFactory.getPropertyBagManager().get(serviceInstanceConfig.getPropertyBagId()).getValue("email-from", null);
		ISendMailManager sendMailManager = ManagerFactory.getSendMailManager();
		if(emailfrom == null)
		{
			IMailConfig mailConfig = sendMailManager.getMailConfig(sessionConfig, transaction);
			emailfrom = mailConfig.getDefaultFromAddress();
		}
		
		StringBuilder emailBody = new StringBuilder();
		
		for(Object fieldObject :this.source.getFields())
		{
			ISourceField field = (ISourceField) fieldObject;
			
			Object parameterValue = this.getParameter(field.getId());
			if(parameterValue != null)
			{
				emailBody.append("<label>"+field.getName()+"</label>: ");
				String value = field.getConverter().convert(String.class, parameterValue);
				emailBody.append(value);
				emailBody.append("<br/><br/>");
			}
			
		}
		
        ISingleMail mail = sendMailManager.createSingleMail();  
        mail.setTo(emailto);
        mail.setSourceComponent(serviceInstanceConfig.getName());  
        mail.setFrom(emailfrom);
        mail.setSubject(serviceInstanceConfig.getName());  
        mail.setCharset("utf-8");
        mail.getBody().setHtmlMsg(emailBody.toString());
        
        sendMailManager.addMailToSendQueue(SessionConfig.getCurrentSessionConfig(), mail, null, transaction);
        
		super.processAction();
	}
	
}

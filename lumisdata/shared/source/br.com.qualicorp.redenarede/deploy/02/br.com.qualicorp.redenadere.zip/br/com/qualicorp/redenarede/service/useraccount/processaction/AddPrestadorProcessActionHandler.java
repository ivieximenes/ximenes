package br.com.qualicorp.redenarede.service.useraccount.processaction;

import lumis.doui.table.TableAddDataProcessActionHandler;
import lumis.portal.PortalException;
import lumis.portal.PortalObjectNotFoundException;
import lumis.portal.UnexpectedException;
import lumis.portal.authentication.SessionConfig;
import lumis.portal.group.IGroupManager;
import lumis.portal.manager.ManagerFactory;
import lumis.portal.principal.PrincipalConfig;
import lumis.portal.user.UserConfig;

public class AddPrestadorProcessActionHandler extends TableAddDataProcessActionHandler
{
	
	final String  QC_PRESTADOR = "qc.prestador";
	@Override
	public void processAction() throws PortalException
	{	
		try{
			try
			{
				String userIdByLogin = ManagerFactory.getUserManager().getUserIdByLogin(SessionConfig.getCurrentSessionConfig(), (String) getParameter("email"), transaction);
				if(userIdByLogin !=null)
					throw new PortalException("Usuário: '"+(String) getParameter("cod_operadora_prest")+"' já cadastrado.");
			}
			catch(PortalObjectNotFoundException p)
			{
				/*PrestadorWebServiceManager prestadorWS = new PrestadorWebServiceManager();
				try {
				RetornoUsuarioPrestador cadastrarPrestador = prestadorWS.cadastrarPrestador(douiContext.getRequest());
				if(!cadastrarPrestador.isSucesso())
					throw new PortalException(cadastrarPrestador.getMensagem());
					
				} catch (Exception e) {
					throw new PortalException(e.getMessage());
				}*/
				
			}
			setParameter("user_id", addUser());
			super.processAction();
		}catch(Exception e)
		{
			 throw new PortalException(e.getMessage(), getResource());
		}
		
		
	}


	private String addUser() throws PortalException, UnexpectedException {
		UserConfig userConfig = new UserConfig();
		userConfig.setLogin((String) getParameter("email"));
		userConfig.setFirstName((String) getParameter("nome"));
		userConfig.setEmail((String) getParameter("email"));
		userConfig.setPassword((String) getParameter("password"));
		
		SessionConfig systemUser = ManagerFactory.getAuthenticationManager().impersonate(UserConfig.USER_SYSTEM_ID);
		String userId = null;
		try
		{
			
			userId = ManagerFactory.getUserManager().add(systemUser, userConfig, transaction);
			
			PrincipalConfig grupo = ManagerFactory.getPrincipalManager().getByShortId(systemUser, QC_PRESTADOR, transaction);
			IGroupManager manager = ManagerFactory.getGroupManager();
            manager.addMember(systemUser, grupo.getId(), userConfig.getId(), transaction);
        }
		catch(Exception e)
        {
            throw new PortalException(e.getMessage(), getResource());
        }
		finally
		{
			ManagerFactory.getAuthenticationManager().endImpersonation(systemUser);
		}
		return userId;
	}

}
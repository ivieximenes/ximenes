package br.com.qualicorp.redenarede.service.login.processaction;

import lumis.doui.processaction.ProcessActionHandler;
import lumis.doui.table.TableSource;
import lumis.portal.PortalException;
import lumis.portal.authentication.AuthenticationDaoJdbc;
import lumis.portal.manager.ManagerFactory;
import lumis.util.XmlUtil;

public class AlterarSenhaProcessActionHandler  extends ProcessActionHandler<TableSource>
	{
		public static final String ACTION_BENEFICIARIO = "alterarSenhaBeneficiario";
		public static final String ACTION_PRESTADOR = "alterarSenhaPrestador";

		@Override
		public void processAction() throws PortalException
		{
			String actionType = XmlUtil.readAttributeString("actionType", processActionNode);

			if (actionType.equals(ACTION_BENEFICIARIO))
				processBeneficiarioAction();
			else if (actionType.equals(ACTION_PRESTADOR))
				processPrestadorAction();
						
			addDefaultResponse();
		}
		
		private void processBeneficiarioAction() throws PortalException
		{
				String login = getParameter("login", String.class); 
				String password = getParameter("password", String.class);
				
				String newPassword = getParameter("newPassword", String.class);
				String confirmNewPassword = getParameter("confirmNewPassword", String.class);
				try
				{
					AuthenticationDaoJdbc authenticationDaoJdbc = new AuthenticationDaoJdbc();
					password = ManagerFactory.getCryptoManager().getOneWayCipher().encrypt(password);
					boolean validateUserLogin = authenticationDaoJdbc.validateUserLogin(login, password, transaction);
					if(!validateUserLogin)
					{
						throw new PortalException("STR_CURRENT_PASSWORD_DOES_NOT_MATCH", getResource());
					}else if(newPassword.equals(confirmNewPassword))
					{
						/*BeneficiarioWebServiceManager beneficiario = new BeneficiarioWebServiceManager();
						TrocarSenhaResponse alterarSenha = beneficiario.alterarSenha(login, password, newPassword, confirmNewPassword);
						if(!alterarSenha.isResultado())
							throw new PortalException(alterarSenha.getMensagem());*/
						
						ManagerFactory.getUserManager().setPassword(sessionConfig, sessionConfig.getUserId(), confirmNewPassword, transaction);
					}else
					{
						throw new PortalException("PASSWORD_DOES_NOT_EQUALS", getResource());
					}
					
				}
				catch(Exception e)
				{
					throw new PortalException(e.getMessage());
				}
				
		}
		
		private void processPrestadorAction() throws PortalException
		{
			String login = getParameter("email", String.class); 
			String password = getParameter("password", String.class);
			
			String newPassword = getParameter("newPassword", String.class);
			String confirmNewPassword = getParameter("confirmNewPassword", String.class);
			try
			{
				AuthenticationDaoJdbc authenticationDaoJdbc = new AuthenticationDaoJdbc();
				password = ManagerFactory.getCryptoManager().getOneWayCipher().encrypt(password);
				boolean validateUserLogin = authenticationDaoJdbc.validateUserLogin(login, password, transaction);
				if(!validateUserLogin)
				{
					throw new PortalException("STR_CURRENT_PASSWORD_DOES_NOT_MATCH", getResource());
				}else if(newPassword.equals(confirmNewPassword))
				{
					
					
					ManagerFactory.getUserManager().setPassword(sessionConfig, sessionConfig.getUserId(), confirmNewPassword, transaction);
				}else
				{
					throw new PortalException("PASSWORD_DOES_NOT_EQUALS", getResource());
				}
				
			}
			catch(Exception e)
			{
				throw new PortalException(e.getMessage());
			}
			
		}
		
}

package br.com.qualicorp.redenarede.webservice.manager;

import java.io.File;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import br.com.qualicorp.redenarede.webservice.stub.pretador.AlterarSenhaUsuarioPrestador;
import br.com.qualicorp.redenarede.webservice.stub.pretador.CadastrarUsuarioPrestador;
import br.com.qualicorp.redenarede.webservice.stub.pretador.RecuperarSenhaUsuarioPrestador;
import br.com.qualicorp.redenarede.webservice.stub.pretador.RecuperarSenhaUsuarioPrestadorResponse;
import br.com.qualicorp.redenarede.webservice.stub.pretador.RetornoUsuarioPrestador;
import br.com.qualicorp.redenarede.webservice.stub.pretador.ServicoPrestador;
import br.com.qualicorp.redenarede.webservice.stub.pretador.UsuarioPrestador;
import br.com.qualicorp.redenarede.webservice.stub.pretador.ValidarUsuarioPrestador;
import lumis.portal.PortalContext;
import lumis.portal.PortalException;
import lumis.portal.serviceinterface.IServiceInterfaceRequest;
import lumis.util.XmlUtil;

public class PrestadorWebServiceManager {

	ServicoPrestador service;
	public PrestadorWebServiceManager() throws Exception
	{
		try {
			Document dom = XmlUtil.getDocument(new File(PortalContext.getConfigPath("/webServiceConfig.xml")));
			Node config = XmlUtil.selectSingleNode("/webServiceConfig/prestador", dom);
			service = new ServicoPrestador(new URL(XmlUtil.readAttributeOrNodeString(config, "wsdlLocation")));
			ignoreSSL();
		} catch (PortalException e) {
			throw new PortalException(e.getMessage());
		}
	}
	public RetornoUsuarioPrestador cadastrarPrestador(IServiceInterfaceRequest request) throws Exception
	{
		RetornoUsuarioPrestador response = new RetornoUsuarioPrestador();
		try {
			
			UsuarioPrestador usuario = new UsuarioPrestador();
			usuario.setEmail(request.getParameter("email"));
			usuario.setCPFCNPJ(request.getParameter("cpf_cnpj"));
			usuario.setRazaoSocial(request.getParameter("razao_social"));
			usuario.setTelefone(request.getParameter("telefone"));
			usuario.setSenhaAtual(request.getParameter("password"));
			CadastrarUsuarioPrestador parameters = new CadastrarUsuarioPrestador();
			parameters.setUsuarioPrestador(usuario);
			response = service.getBasicHttpBindingIServicoPrestador().cadastrarUsuarioPrestador(parameters ).getCadastrarUsuarioPrestadorResult();
			
		} catch (Exception e) {
			throw new PortalException(e.getMessage());
		}
		return response;
	}
	
	public RetornoUsuarioPrestador login(String login, String password) throws PortalException {
		RetornoUsuarioPrestador response = new RetornoUsuarioPrestador();
		try
		{
			ValidarUsuarioPrestador parameters = new ValidarUsuarioPrestador();
			UsuarioPrestador usuario = new UsuarioPrestador();
			usuario.setEmail(login);
			usuario.setSenhaAtual(password);
			parameters.setUsuarioPrestador(usuario );
			response = service.getBasicHttpBindingIServicoPrestador().validarUsuarioPrestador(parameters ).getValidarUsuarioPrestadorResult();
		}catch(Exception e)
		{
			throw new PortalException(e.getMessage());
		}
		return response;
	}
	
	
	public RecuperarSenhaUsuarioPrestadorResponse recuperarSenha(String cpfCnpj, String email) throws PortalException {
		RecuperarSenhaUsuarioPrestadorResponse response = new RecuperarSenhaUsuarioPrestadorResponse();
		try
		{
			UsuarioPrestador usuario = new UsuarioPrestador();
			usuario.setEmail(email);
			usuario.setCPFCNPJ(cpfCnpj);
			RecuperarSenhaUsuarioPrestador parameters = new RecuperarSenhaUsuarioPrestador();
			parameters.setUsuarioPrestador(usuario);
			response = service.getBasicHttpBindingIServicoPrestador().recuperarSenhaUsuarioPrestador(parameters);
		}catch(Exception e)
		{
			throw new PortalException(e.getMessage());
		}
		return response;
	}
	
	public RetornoUsuarioPrestador alterarSenha(IServiceInterfaceRequest request) throws Exception
	{
		RetornoUsuarioPrestador response = new RetornoUsuarioPrestador();
		try {
			
			UsuarioPrestador usuario = new UsuarioPrestador();
			usuario.setEmail(request.getParameter("email"));
			usuario.setCPFCNPJ(request.getParameter("cpf_cnpj"));
			usuario.setRazaoSocial(request.getParameter("razao_social"));
			usuario.setTelefone(request.getParameter("telefone"));
			usuario.setSenhaAtual(request.getParameter("password"));
			AlterarSenhaUsuarioPrestador parameters = new AlterarSenhaUsuarioPrestador();
			parameters.setUsuarioPrestador(usuario);
			response  = service.getBasicHttpBindingIServicoPrestador().alterarSenhaUsuarioPrestador(parameters).getAlterarSenhaUsuarioPrestadorResult();
			
		} catch (Exception e) {
			throw new PortalException(e.getMessage());
		}
		return response;
	}
	
	
	/**
	 * Ignora certificados SSL invalidos
	 */
	private void ignoreSSL() {
		TrustManager[] trustAllCerts = new TrustManager[]{
		    new X509TrustManager() {
		        public void checkClientTrusted(
		            java.security.cert.X509Certificate[] certs, String authType) {
		        }
		        public void checkServerTrusted(
		            java.security.cert.X509Certificate[] certs, String authType) {
		        }
		        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		            return null;
		        }
		    }
		};

		// Install the all-trusting trust manager
		try {
		    SSLContext sc = SSLContext.getInstance("SSL");
		    sc.init(null, trustAllCerts, new java.security.SecureRandom());
		    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
		}
	}
	
	
}

@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.common.tempoassist.com.br/schema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.qualicorp.redenarede.webservice.stub.beneficiario;

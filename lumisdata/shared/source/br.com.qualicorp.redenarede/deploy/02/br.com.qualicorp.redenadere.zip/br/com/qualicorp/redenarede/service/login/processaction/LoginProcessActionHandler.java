package br.com.qualicorp.redenarede.service.login.processaction;

import java.util.Locale;

import br.com.qualicorp.redenarede.webservice.manager.PrestadorWebServiceManager;
import br.com.qualicorp.redenarede.webservice.stub.pretador.RetornoUsuarioPrestador;
import lumis.doui.processaction.ProcessActionHandler;
import lumis.doui.table.TableSource;
import lumis.portal.PortalException;
import lumis.portal.UnexpectedException;
import lumis.portal.authentication.SessionConfig;
import lumis.portal.manager.ManagerFactory;
import lumis.portal.page.PageConfig;
import lumis.portal.page.acl.PagePermissions;
import lumis.portal.principal.PrincipalConfig;
import lumis.portal.serviceinterface.IServiceInterfaceUrl;
import lumis.portal.user.UserConfig;
import lumis.util.CookieUtil;
import lumis.util.XmlUtil;

public class LoginProcessActionHandler  extends ProcessActionHandler<TableSource>
	{
		public static final String ACTION_LOGIN = "lum_actionLogin";
		public static final String ACTION_LOGOUT = "lum_actionLogout";
		public static final String  QC_BENEFICIARIO = "qc.beneficiario";
		public static final String  QC_PRESTADOR = "qc.prestador";

		@Override
		public void processAction() throws PortalException
		{
			String actionType = XmlUtil.readAttributeString("actionType", processActionNode);

			if (actionType.equals(ACTION_LOGIN))
				processLoginAction();
			else if (actionType.equals(ACTION_LOGOUT))
				processLogoutAction();
						
			addDefaultResponse();
		}
		
		private void processLoginAction() throws PortalException
		{
			try
			{
				String email = getParameter("login", String.class); 
				String password = getParameter("password", String.class);
		
				if (email != null)
				{
					
					String userId = ManagerFactory.getUserManager().getUserIdByLogin(sessionConfig, email, transaction);
					PrincipalConfig beneficiarios = ManagerFactory.getPrincipalManager().getByShortId(sessionConfig, QC_BENEFICIARIO, transaction);
					PrincipalConfig prestadores = ManagerFactory.getPrincipalManager().getByShortId(sessionConfig, QC_BENEFICIARIO, transaction);
					boolean isPrestador = ManagerFactory.getGroupManager().isMember(sessionConfig, prestadores.getId(), userId, transaction);
					boolean isBeneficiario = ManagerFactory.getGroupManager().isMember(sessionConfig, beneficiarios.getId(), userId, transaction);
					if(isBeneficiario)
					{
						/*BeneficiarioWebServiceManager beneficiarioWS  = new BeneficiarioWebServiceManager();
						AutenticarResponse loginBeneficiario = beneficiarioWS.login(email, password);
						if(!loginBeneficiario.isResultado())
							throw new PortalException(loginBeneficiario.getMensagem());*/
						
						ManagerFactory.getAuthenticationManager().loginUser(userId, transaction);
						CookieUtil.addLumisUserCookies(douiContext.getRequest(), douiContext.getResponse());
						
						IServiceInterfaceUrl url = getServiceInterfaceHyperLink(douiContext.getRequest().getServiceConfig().getId()+".homeBeneficiario");
						douiContext.getActionResponse().sendRedirect(url.toString());
					}else if(isPrestador)
					{
						PrestadorWebServiceManager prestadorWS = new PrestadorWebServiceManager();
						RetornoUsuarioPrestador loginPrestador = prestadorWS.login(email, password);
						if(!loginPrestador.isSucesso())
							throw new PortalException(loginPrestador.getMensagem());
						
						ManagerFactory.getAuthenticationManager().loginUser(userId, transaction);
						CookieUtil.addLumisUserCookies(douiContext.getRequest(), douiContext.getResponse());
						
						IServiceInterfaceUrl url = getServiceInterfaceHyperLink(douiContext.getRequest().getServiceConfig().getId()+".homePrestador");
						douiContext.getActionResponse().sendRedirect(url.toString());
					}else
					{
						SessionConfig loginUser = ManagerFactory.getAuthenticationManager().login(email, password, transaction);
						if (loginUser != null)
						{
							CookieUtil.addLumisUserCookies(douiContext.getRequest(), douiContext.getResponse());
							douiContext.getActionResponse().sendRedirect("/"+ PageConfig.PAGE_MAIN);	
							
						}
						else
						{
							throw new PortalException("STR_ERROR_MSG", getResource());
						}
					}
					
				}
			}
			catch (PortalException e)
			{
				throw e;
			}
			catch (Exception e)
			{
				throw new UnexpectedException(e);
			}
		}
		
		private void processLogoutAction() throws PortalException
		{
			try
			{
				Locale originalSessionConfigLocale = sessionConfig.getLocale();
				
				// logout the user
				ManagerFactory.getAuthenticationManager().logoutUser(sessionConfig, transaction);
				CookieUtil.deleteLumisStandardCookies(douiContext.getRequest(), douiContext.getResponse());
				douiContext.getRequest().getPortletSession().invalidate();
				
				// from now on, this request must be processed as a guest user in
				// the same locale as the original session
				SessionConfig guestSessionConfig = ManagerFactory.getAuthenticationManager().impersonate(UserConfig.USER_GUEST_ID);
				guestSessionConfig.setLocale(originalSessionConfigLocale);

				// reads the original web resource path from the request
				String originalWebResource = getParameter("originalWebResource", String.class);

				// checks whether the user may stay in the same page
				boolean mayStayInTheSamePage =
						originalWebResource != null
						&& !originalWebResource.isEmpty()
						&& ManagerFactory.getPageAclManager().checkPermission(guestSessionConfig, douiContext.getRequest().getPageConfig().getId(), PagePermissions.VIEW_PAGE, transaction);

				// if so, redirect him to the very same web resource
				if (mayStayInTheSamePage)
				{
					douiContext.getActionResponse().sendRedirect(douiContext.getActionRequest().getContextPath() + originalWebResource);
				}

				// if not, redirect him to root
				else
				{
					IServiceInterfaceUrl url = douiContext.getResponse().createPortalURL();
					url.setParameter("logout", "1");
					douiContext.getActionResponse().sendRedirect(douiContext.getActionRequest().getContextPath() + "/" + url.toString());
				}
			}
			catch (PortalException e)
			{
				throw e;
			}
			catch (Exception e)
			{
				throw new UnexpectedException(e);
			}
		}
		
}
